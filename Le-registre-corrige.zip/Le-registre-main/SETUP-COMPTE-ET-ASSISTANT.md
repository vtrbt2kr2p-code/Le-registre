# Activer la connexion par e-mail et l'assistant (facultatif)

Ces deux fonctionnalités sont **optionnelles**. Sans elles, l'application
continue de fonctionner exactement comme avant : 100 % hors ligne, données
stockées uniquement sur l'appareil.

## 1. Créer un projet Firebase

1. Allez sur https://console.firebase.google.com et créez un projet
   (gratuit, aucune carte bancaire nécessaire à ce stade).
2. **Authentication** → Sign-in method → activez « E-mail/Lien » (connexion
   sans mot de passe, par lien envoyé par e-mail).
3. **Firestore Database** → Créer une base, en mode production.
4. **Storage** → Commencer, en mode production.
5. **Paramètres du projet** (⚙️) → Vos applications → Ajouter une application
   Web (icône `</>`) → copiez la configuration affichée.

## 2. Configurer le site

Collez la configuration obtenue à l'étape 1.5 dans `firebase-config.js`,
à la place des valeurs `VOTRE_...`.

Tant que ce fichier n'est pas rempli, l'application reste 100 % locale :
aucune fonctionnalité existante n'est cassée.

## 3. Déployer les règles de sécurité

Avec la CLI Firebase (`npm install -g firebase-tools`, puis `firebase login`) :

```bash
firebase use --add          # choisissez votre projet, alias "default"
firebase deploy --only firestore:rules,storage:rules
```

Cela publie `firestore.rules` et `storage.rules`, qui garantissent que
chaque utilisateur ne peut lire/écrire que ses propres données.

## 4. Activer l'assistant (chatbot)

L'assistant tourne dans une Cloud Function (dossier `functions/`), pas dans
le navigateur, car la clé API Anthropic doit rester secrète.

1. Passez le projet Firebase au plan **Blaze** (paiement à l'usage) —
   obligatoire pour qu'une fonction puisse appeler un service externe.
2. Définissez le secret :
   ```bash
   firebase functions:secrets:set ANTHROPIC_API_KEY
   ```
3. Installez les dépendances et déployez :
   ```bash
   cd functions
   npm install
   cd ..
   firebase deploy --only functions
   ```
4. Le déploiement affiche une URL du type
   `https://europe-west1-VOTRE_PROJET.cloudfunctions.net/askAssistant`.
   Collez-la dans `firebase-config.js`, champ `window.CHAT_ENDPOINT`.

Tant que ce champ est vide, le bouton d'assistant reste visible mais
indique clairement qu'il n'est pas encore configuré.

## Important — GitHub Pages

Le site lui-même **reste hébergé sur GitHub Pages**, inchangé. Firebase
n'est utilisé ici que pour trois choses : l'authentification, la base
Firestore (sync multi-appareils) et la Cloud Function de l'assistant.
Aucune de ces étapes ne modifie l'hébergement du site.
